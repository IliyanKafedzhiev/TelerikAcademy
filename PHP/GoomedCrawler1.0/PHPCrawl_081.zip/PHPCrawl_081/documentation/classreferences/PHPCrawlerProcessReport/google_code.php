<?php
if ($_SERVER["SERVER_NAME"] == "phpcrawl.cuab.de")
{
?>
-->
  
<div style="width: 728px !important; margin-right: auto; margin-left: auto;">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-4351312586851155";
/* phpcrawl leaderboard */
google_ad_slot = "2902057176";
google_ad_width = 728;
google_ad_height = 90;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div><br />

<!--
<?php
}
?>